import { useState } from 'react'
import estrutura from './assets/estrutura.png'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <section id="center">
        <div className="hero">
          <img src={estrutura} className="base" width="500" height="200" alt="" />
        </div>
        <div>
          <h1>Somativa</h1>
          <h2>Gui Rocha</h2>
        </div>
        <button
          type="button"
          className="counter"
          onClick={() => setCount((count) => count + 1)}
        >
          Count is {count}
        </button>
      </section>
    </>
  )
}

export default App
